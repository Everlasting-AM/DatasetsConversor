from setuptools import setup

setup(name='aux_libraries',
      version='0.1',
      description='Funciones auxiliares para gestión de argumentos',
      packages=['aux'],
      author_email='am.guerreroserna@gmail.com',
      zip_safe=False)
